Business Icons for Vista

Product page:
http://777icons.com/libs/business-vista-icons.htm
